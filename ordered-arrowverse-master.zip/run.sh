QUART_ENV=development QUART_DEBUG=true QUART_APP=./ordering/ quart run
